<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'];

    if ($type === 'getdata') {
        $sql = "SELECT * FROM freefire";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $rows = array();
            while ($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }
            $json_data = json_encode($rows);
            echo $json_data;
        } else {
            echo "No Matches Found";
        }
    }

    if ($type === 'add') {
        $match_title = $_POST['match_title'];
        $match_time = $_POST['match_time'];
        $total_prize = $_POST['total_prize'];
        $per_kill = $_POST['per_kill'];
        $entry_fee = $_POST['entry_fee'];
        $entry_type = $_POST['entry_type'];
        $match_type = $_POST['match_type'];
        $version = $_POST['version'];
        $play_map = $_POST['play_map'];
        $registration = $_POST['registration'];
        $total_player = $_POST['total_player'];
        $prize_details = $_POST['prize_details'];
        $timer = $_POST['timer'];
        $room_details = "NO";
        $match_result = "NO";

        $sql = "INSERT INTO freefire (match_title, match_time, total_prize, per_kill, entry_fee, entry_type, match_type, version, play_map, registration, total_player, prize_details, room_details, match_result, timer) VALUES ('$match_title', '$match_time', '$total_prize', '$per_kill', '$entry_fee', '$entry_type', '$match_type', '$version', '$play_map', '$registration', '$total_player', '$prize_details', '$room_details', '$match_result', '$timer')";

        if ($conn->query($sql) === TRUE) {
            echo "Add Matches Successfully";
        } else {
            echo "Error Add Matches: " . $conn->error;
        }
    }

    if ($type === 'delete') {
        $id = $_POST['id'];

        $sql = "DELETE FROM freefire WHERE id='$id'";

        if ($conn->query($sql) === TRUE) {
            echo "Match Deleted Successfully";
        } else {
            echo "Error Deleting Match: " . $conn->error;
        }
    }
    
    if ($type === 'move') {
        $result = $_POST['result'];
        $id = $_POST['id'];
        
        $sql = "UPDATE freefire SET match_result = '$result' WHERE id='$id'";

        if ($conn->query($sql) === TRUE) {
            echo "Match Moved Successfully";
        } else {
            echo "Error Updating Record: " . $conn->error;
        }
    }
    
    if ($type === 'update') {
        $id = $_POST['id'];
        $match_title = $_POST['match_title'];
        $match_time = $_POST['match_time'];
        $total_prize = $_POST['total_prize'];
        $per_kill = $_POST['per_kill'];
        $registration = $_POST['registration'];
        $total_player = $_POST['total_player'];
        $prize_details = $_POST['prize_details'];
        $room_details = $_POST['room_details'];
        $timer = $_POST['timer'];
    
    $sql = "UPDATE freefire SET match_title='$match_title', match_time='$match_time', total_prize='$total_prize', per_kill='$per_kill', registration='$registration', total_player='$total_player', prize_details='$prize_details', room_details='$room_details', timer='$timer' WHERE id='$id'";

        if (mysqli_query($conn, $sql)) {
            echo "Match Updated Successfully";
        } else {
            echo "Error Updating Match: " . mysqli_error($conn);
        }
    }

    $conn->close();
} else {
    echo "Invalid Request Method";
}
?>