<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'];
    
    if ($type === 'freefire') {
        $total_kill = $_POST['total_kill'];
        $total_win = $_POST['total_win'];
        $email = $_POST['email'];
        $id = $_POST['id'];
        $match_id = $_POST['match_id'];

        $sql = "UPDATE users SET winning=winning+$total_win, total_win=total_win+$total_win, total_kill=total_kill+$total_kill, total_paid=total_paid+$total_win WHERE email='$email'";
        $update = "UPDATE joiners SET total_kill='$total_kill', winning='$total_win' WHERE id='$id'";
        $statistics = "UPDATE statistics SET winnings=winnings+'$total_win' WHERE type='$type' AND match_id='$match_id'";

        if ($conn->query($sql) === TRUE && $conn->query($update) === TRUE && $conn->query($statistics) === TRUE) {
            echo "Winner Added Successfully";
        } else {
            echo "Error Adding Winner: " . $conn->error;
        }
    }
    
    if ($type === 'ludoking') {
        $total_win = $_POST['total_win'];
        $email = $_POST['email'];
        $match_id = $_POST['match_id'];
        $image_id = $_POST['image_id'];
        
        $sql = "UPDATE users SET winning=winning+$total_win, total_win=total_win+$total_win,total_paid=total_paid+$total_win WHERE email='$email'";
        $update = "UPDATE joiners SET winning='$total_win' WHERE type='$type' AND match_id='$match_id'";
        $delete = "DELETE FROM upload WHERE id = $image_id";
        $statistics = "UPDATE statistics SET winnings=winnings+'$total_win' WHERE type='$type' AND match_id='$match_id'";

        if ($conn->query($sql) === TRUE && $conn->query($update) === TRUE && $conn->query($delete) === TRUE && $conn->query($statistics) === TRUE) {
            echo "Winner Added Successfully";
        } else {
            echo "Error Adding Winner: " . $conn->error;
        }
    }    

    $conn->close();
} else {
    echo "Invalid Request Method";
}
?>