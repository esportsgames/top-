<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'];

    if ($type === 'one') {
        $email = $_POST['email'];

        $query = "SELECT * FROM users WHERE email = '$email'";
        $result = mysqli_query($conn, $query);

        if ($result) {
            $data = mysqli_fetch_assoc($result);

            if ($data) {
                echo json_encode($data);
            } else {
                echo json_encode(['Error' => 'No User Found']);
            }
        } else {
            echo json_encode(['Error' => mysqli_error($conn)]);
        }
    }

    if ($type === 'edit') {
        $email = $_POST['email'];
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $number = $_POST['number'];

        $sql = "UPDATE users SET first_name='$first_name', last_name='$last_name', number='$number' WHERE email='$email'";

        if (mysqli_query($conn, $sql)) {
            echo "Profile Updated Successfully";
        } else {
            echo "Error Updating Profile: " . mysqli_error($conn);
        }
    }

    if ($type === 'pass') {
        $email = $_POST['email'];
        $oldpass = $_POST['oldpass'];
        $newpass = $_POST['newpass'];

        $query = "SELECT * FROM users WHERE email = '$email' AND password = '$oldpass'";
        $result = mysqli_query($conn, $query);

        if ($result->num_rows > 0) {
            $sql = "UPDATE users SET password='$newpass' WHERE email='$email'";

            if (mysqli_query($conn, $sql)) {
                echo "Password Changed Successfully";
            } else {
                echo "Error Changing Password: " . mysqli_error($conn);
            }
        } else {
            echo "Old Password Is Incorrect!";
        }
    }

    if ($type === 'all') {
        $sql = "SELECT * FROM users";
        $result = $conn->query($sql);

        $dataArray = array();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $dataArray[] = $row;
            }
            echo json_encode($dataArray, JSON_UNESCAPED_UNICODE);
        } else {
            echo "No User Found";
        }
    }

    if ($type === 'delete') {
        $id = $_POST['id'];

        $sql = "DELETE FROM users WHERE id=$id";

        if ($conn->query($sql) === TRUE) {
            echo "User Deleted Successfully";
        } else {
            echo "Error Deleting User: " . $conn->error;
        }
    }
    
    if ($type === 'update') {
        $id = $_POST['id'];
        $password = $_POST['password'];
        $balance = $_POST['balance'];
        $winning = $_POST['winning'];
        $device_id = $_POST['device_id'];
        $status = $_POST['status'];

        $sql = "UPDATE users SET password='$password', balance='$balance', winning='$winning', device_id='$device_id', status='$status' WHERE id=$id";

        if ($conn->query($sql) === TRUE) {
            echo "User Updated Successfully";
        } else {
            echo "Error Updating User: " . $conn->error;
        }
    }

    mysqli_close($conn);
} else {
    echo json_encode(['Error' => 'Invalid Request Method']);
}
?>